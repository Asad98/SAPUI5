sap.ui.define([								//Scaffolding
	"sap/ui/core/mvc/Controller",
	"companyname/model/model",
	"companyname/formatter/formatter_lifesaver"
], function(Controller, myModel,formatter_lifesaver) {
	
	"use strict";

	return Controller.extend("companyname.controller.employeeform", {
		//Global Variables
		formatter: formatter_lifesaver,
		oCore: sap.ui.getCore(),
		//onInit function is run once and is run when the application loads initially
		onInit: function() {
			/*var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData({

				"empStr": {
					"empID": "100",
					"empName": "Asad",
					"empSalary": "50000",
					"empCurrency": "USD"
				},
				"empTab": [{
					"empID": "101",
					"empName": "John",
					"empSalary": "40000",
					"empCurrency": "INR"
				}, {
					"empID": "102",
					"empName": "Loki",
					"empSalary": "30000",
					"empCurrency": "DHS"
				}]

			});*/
			var oModel = myModel.createMyJSONModel("model/mockData/data.json");
			sap.ui.getCore().setModel(oModel);
			
			var oResource = myModel.createResourceModel();
			sap.ui.getCore().setModel(oResource,"i18n");
			
			/*var oModelXML = myModel.createMyXMLModel("model/mockData/XMLdata.xml");
			sap.ui.getCore().setModel(oModelXML);*/
			
			//Different Data Binding syntax 
			/*var oSalary= this.getView().byId("idSal");
			var oCurrency= this.getView().byId("idCurrency");
			oSalary.bindValue("/empStr/empSalary");
			oCurrency.bindProperty("value","/empStr/empCurrency");*/
		},
		
		changeData: function(){
			var oModel= sap.ui.getCore().getModel();
			oModel.setProperty("/empStr/empID",oModel.getProperty("/empTab/2/empID"));
			oModel.setProperty("/empStr/empName",oModel.getProperty("/empTab/2/empName"));
			oModel.setProperty("/empStr/empSalary",oModel.getProperty("/empTab/2/empSalary"));
			oModel.setProperty("/empStr/empCurrency",oModel.getProperty("/empTab/2/empCurrency"));
		/*	oSalary.bindValue("/empTab/2/empSalary");
			oCurrency.bindProperty("value","/empTab/2/empCurrency");
			oEmpId.bindValue("/empTab/2/empID");
			oEmpName.bindValue("/empTab/2/empName");*/
		},
		
		showData: function(){
			var oModel= sap.ui.getCore().getModel();
			var oEmpId= oModel.getProperty("/empStr/empID");
			var oEmpName= oModel.getProperty("/empStr/empName");
			var oSalary= oModel.getProperty("/empStr/empSalary");
			var oCurrency= oModel.getProperty("/empStr/empCurrency");
			console.log("Employee ID - "+oEmpId+"\n"+"Employee Name - "+oEmpName+"\n"+"Salary - "+oSalary+"\n"+"Currency - "+oCurrency);
		},
		
		onRowSelect: function(oEvent){
			//I need to know which record was clicked by user
			var oContext = oEvent.getParameter("rowContext");
			//Get address of the element memory of that record
			var oElement = oContext.getPath();
			//Connect our simple form with the element address as absolute path
			var oSimple = this.getView().byId("simpleForm");
			oSimple.bindElement(oElement);
			//Children of simpleform must have relative path binding
			
		},
		
		onExit: function(){
			
		},
		
		onBeforeRendering: function(){
			
		},
		
		onAfterRendering: function(){
			/*setInterval(function(){
				$("#idXMLView--empFormTab-sapUiTableCnt").fadeOut(1000,function(){
					$("#idXMLView--empFormTab-sapUiTableCnt").fadeIn(1000);
				});
			});*/
		}
		
	});

});
sap.ui.define(
	[],							//Scaffolding
	function() {
		return {				//returns JS code
			createMyJSONModel: function(sPath) {		//function to load the data from JSON file-data.json
				var oModel = new sap.ui.model.json.JSONModel();		//empty JSON model
			//	oModel.setData();
				//Default Binding Mode of JSON is two-way binding. However, we can change it to 
				//One-way meaning you can only send data from JSON to view and cannot retrieve the data from view if data is changed.
				//In this case the data iin the field is loaded from data.json which is ASAD but if user changes it to something else and you want to retrieve it 
				//you can only retrieve it in two-way and not in one-way, if you try to retrieve it on one-way you will recieve ASAD only.
				//oModel.setDefaultBindingMode("OneWay");
				oModel.loadData("/model/mockData/data.json");		//loading JSON data from external file
				return oModel;	//returns the JSON data after loading, into the function
			},
			createMyXMLModel: function(sPath) {		//function to load the data from JSON file-data.json
				var oModel = new sap.ui.model.xml.XMLModel();		//empty JSON model
			//	oModel.setData();
				//Default Binding Mode of XML is also two-way binding. However, we can change it to 
				//One-way meaning you can only send data from JSON to view and cannot retrieve the data from view if data is changed.
				//In this case the data iin the field is loaded from data.json which is ASAD but if user changes it to something else and you want to retrieve it 
				//you can only retrieve it in two-way and not in one-way, if you try to retrieve it on one-way you will recieve ASAD only.
				//oModel.setDefaultBindingMode("OneWay");
				oModel.loadData("/model/mockData/XMLdata.xml");		//loading JSON data from external file
				return oModel;	//returns the JSON data after loading, into the function
			},
			createResourceModel: function(){
				var oResource = new sap.ui.model.resource.ResourceModel({
					bundleUrl : "i18n/i18n.properties"
				});
				return oResource;
			}
			
		};
	});
sap.ui.define(
	[], 
	function(){
		return {
			convertToUpper: function(inp){
				console.log(inp);
				var Upcase=inp.toUpperCase();
				return Upcase;
			}
		};
	}
);